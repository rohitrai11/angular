import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mypipe'
})
export class MypipePipe implements PipeTransform {

  transform(flightId: any, args?: any): any {
    var arr=flightId.split(/\d/g);
    return String(arr[1]);
  }

}
