import { Component, OnInit } from '@angular/core';
import { Boat } from '../Boat';
import {BoatService} from '../boat.service';
@Component({
  selector: 'displayboat',
  templateUrl: './displayboat.component.html',
  styleUrls: ['./displayboat.component.css']
})
export class DisplayboatComponent implements OnInit {
  show: boolean = false;
  boatToDisplay:Boat;
  myclass:string;
  b:string="blue";
  g:string="green";
  selectedRow:number;
  flag:boolean=false;
  bcolor:string="pink";
  constructor(private boatService:BoatService) { 
    
  }
  setClickedRow(rowNo:number){
    alert(rowNo)
    this.selectedRow=rowNo;
  }
  showBoat(boat:Boat) {
    this.boatToDisplay=boat;
   this.show=this.show?false:true;
}
changeStyle(){
  this.flag=this.flag?false:true;
  
  this.myclass="styleclass1";
}
changeStyle2(){
  this.flag=this.flag?false:true;
  this.myclass="styleclass2";
}
BOATS:Boat[]   
  

  ngOnInit() {
    this.BOATS=this.boatService.getAllBoats();
  }

}
