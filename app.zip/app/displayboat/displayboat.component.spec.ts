import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayboatComponent } from './displayboat.component';

describe('DisplayboatComponent', () => {
  let component: DisplayboatComponent;
  let fixture: ComponentFixture<DisplayboatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayboatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayboatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
