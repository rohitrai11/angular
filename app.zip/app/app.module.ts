import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule,FormGroup } from '@angular/forms';


import { AppComponent } from './app.component';
import { DisplayboatComponent } from './displayboat/displayboat.component';
import { BoatDetailsComponent } from './boat-details/boat-details.component';
import {BoatService} from './boat.service'






@NgModule({
  declarations: [
    AppComponent,
    DisplayboatComponent,
    BoatDetailsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [BoatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
