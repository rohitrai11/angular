import { Injectable } from '@angular/core';
import {Boat} from './Boat'

@Injectable()
export class BoatService {

  constructor() { }
  getAllBoats():Boat[]{
    var start = new Date().getTime();      
    var end = start;      
    while(end < start + 5000) {      
        end = new Date().getTime();      
    } 
    var boats:Boat[] = [
      new Boat("1001","Houseboat","Allepy",999.0,5,.8,new Date(2019,3,12),"This is house boat service",""),
      new Boat("1002","Houseboat","Goa",999.0,5,.8,new Date(2019,2,12),"This is house boat service",""),
      new Boat("1003","Houseboat","Allepy",499.0,5,.8,new Date(2019,7,12),"This is house boat service","")
      
    ];     
    return boats; 

  }
        
    
    
}

