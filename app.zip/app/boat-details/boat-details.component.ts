import { Component, OnInit, Input } from '@angular/core';
import {Boat} from '../boat'

@Component({
  selector: 'boat-details',
  templateUrl: './boat-details.component.html',
  styleUrls: ['./boat-details.component.css']
})
export class BoatDetailsComponent implements OnInit {

  constructor() { }
  @Input()
  choosenBoat:Boat;
  ngOnInit() {
  }

}
