import { Injectable } from '@angular/core';
import {Boat} from './Boat'
import {Http,Headers} from '@angular/http'
import 'rxjs/add/operator/toPromise'

@Injectable()
export class BoatService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }
  getAllBoats(): Promise<Boat[]> {
    
    return this.http.get('http://localhost:8765/SeaQueenBoats/sqbBoats/boatsAll')    
    .toPromise()    
    .then(response=>response.json() as Boat[])    
    .catch(this.errorHandler);
    }
    
    private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.message || error);
    }
  book(data):Promise<any>{
    const url = 'http://localhost:8765/SeaQueenBoats/sqbBoats/boatAdd'; //Line 2
    return this.http.post(url, JSON.stringify(data), {headers: this.headers}) //Line 3
    .toPromise()
    .then(
      
    (res) =>res.json()
    ).catch(this.errorHandler2);
  }
  private errorHandler2(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

}
  
        
    
    


