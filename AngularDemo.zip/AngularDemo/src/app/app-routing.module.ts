import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DisplayboatComponent } from './displayboat/displayboat.component';
import { BoatDetailsComponent } from './boat-details/boat-details.component';
import { AddboatComponent } from './addboat/addboat.component';

const routes: Routes = [
    
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path:'displayboats', component: DisplayboatComponent },
  { path: 'boatAdd', component: AddboatComponent}, // adding a new Boat
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }