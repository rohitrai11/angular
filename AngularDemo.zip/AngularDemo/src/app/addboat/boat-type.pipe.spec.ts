import { BoatTypePipe } from './boat-type.pipe';

describe('BoatTypePipe', () => {
  it('create an instance', () => {
    const pipe = new BoatTypePipe();
    expect(pipe).toBeTruthy();
  });
});
