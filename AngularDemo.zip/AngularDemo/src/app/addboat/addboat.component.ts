import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {BoatService} from '../boat.service';
import {BasePriceValidator} from './baseprice-validiator'

@Component({
  selector: 'addboat',
  templateUrl: './addboat.component.html',
  styleUrls: ['./addboat.component.css']
})
export class AddboatComponent implements OnInit {

  constructor(private formBuilder:FormBuilder,private boatService:BoatService) { }
  boatTypes:string[]=['Houseboat','Cruiser','Bass Boat','Speed Boat','Power Catamaran'];
  bookingForm:FormGroup;
  successMessage:string;
  errorMessage:string;
  ngOnInit() {
    this.bookingForm=this.formBuilder.group({boatType:["",[Validators.required]],location:["",[Validators.required]],
    basePrice:["",[Validators.required,BasePriceValidator.checkPrice]],bookingStart:["",[Validators.required]]})  
  }
  add(){
    alert("add caled")
    this.successMessage=null;
    this.errorMessage=null;
    alert(this.bookingForm.value.location)
    this.boatService.book(this.bookingForm.value).then(response=>this.successMessage=response.message).catch(response=>this.errorMessage=response.message)  
  }

}
