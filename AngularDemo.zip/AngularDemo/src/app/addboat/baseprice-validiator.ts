import { AbstractControl, ValidationErrors } from "@angular/forms";

export class BasePriceValidator {
    static checkPrice(name: AbstractControl):ValidationErrors|null 
    {
        let basePrice:number=name.value as number;
        if((basePrice<0 && basePrice<2000) )
        return {checkPrice:true};
        else
        {
            return null;
        }
    }

}