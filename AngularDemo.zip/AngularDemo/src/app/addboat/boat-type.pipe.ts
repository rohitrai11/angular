import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'boatType'
})
export class BoatTypePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if(value=="Houseboat"){
      return "HB"
    }
    if(value=="Cruiser"){
      return "CR"
    }
    if(value=="Bass Boat"){
      return "BB";
    }
    if(value=="Speed Boat"){
      return "SB"
    }
    if(value=="Power Catamaran"){
      return "PC";
    }
    else{
      return null;
    }
  }

}
