export class Boat {
	
	constructor(public boatId:string,public boatType:string,public location:string,
	public basePrice:number,public allowedDays:number,public discount,public bookingStart:Date,public description:string,public message:string){

	}
}