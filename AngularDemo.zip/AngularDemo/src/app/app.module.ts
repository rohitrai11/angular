import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule,FormGroup } from '@angular/forms';
import {HttpModule} from '@angular/http'

import { AppComponent } from './app.component';
import { DisplayboatComponent } from './displayboat/displayboat.component';
import { BoatDetailsComponent } from './boat-details/boat-details.component';
import {BoatService} from './boat.service';
import { AddboatComponent } from './addboat/addboat.component';
import { BoatTypePipe } from './addboat/boat-type.pipe'
import {AppRoutingModule} from './app-routing.module'






@NgModule({
  declarations: [
    AppComponent,
    DisplayboatComponent,
    BoatDetailsComponent,
    AddboatComponent,
    BoatTypePipe
  ],
  imports: [
    BrowserModule,HttpModule,ReactiveFormsModule,AppRoutingModule
  ],
  providers: [BoatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
