var movies = [{ "movieName": "Star Wars", "rating": 5 }, { "movieName": "Titanic", "rating": 4.5 }, { "movieName": "Terminator", "rating": 3 }];
var filteredMovie = [];
function filterMovies(movieList) {
    for (var _i = 0, movieList_1 = movieList; _i < movieList_1.length; _i++) {
        var m = movieList_1[_i];
        if (m["rating"] > 4) {
            filteredMovie.push(m);
        }
    }
}
filterMovies(movies);
for (var _i = 0, filteredMovie_1 = filteredMovie; _i < filteredMovie_1.length; _i++) {
    var m = filteredMovie_1[_i];
    console.log(m);
}
