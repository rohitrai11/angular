export enum ProductType{
    APPAREL=2001,
    ELCTRONICS=2002,
    AUTOMOBILE=2003
}