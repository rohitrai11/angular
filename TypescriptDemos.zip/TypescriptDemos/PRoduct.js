"use strict";
exports.__esModule = true;
var ProductType_1 = require("./ProductType");
var Product = /** @class */ (function () {
    function Product(id, name, price, stock, productType) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.productType = productType;
    }
    Product.prototype.getId = function () {
        return this.id;
    };
    Product.prototype.getName = function () {
        return this.name;
    };
    Product.prototype.getPrice = function () {
        return this.price;
    };
    Product.prototype.getStock = function () {
        return this.stock;
    };
    Product.prototype.display = function () {
        console.log("Id is " + this.id + " Name is\
        " + this.name + " Price " + this.price + " Stock " + this.stock + ProductType_1.ProductType[this.productType]);
    };
    return Product;
}());
exports.Product = Product;
