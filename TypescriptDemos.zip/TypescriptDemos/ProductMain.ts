import {Product} from './Product';
import {ProductType} from './ProductType'
var p:Product=new Product(1001,"Jeans",499.00,35,ProductType.APPAREL);
p.display();
var pList:Product[]=[
    new Product(1002,"T-Shirt",200.0,20,ProductType.AUTOMOBILE),
    new Product(1003,"Helmet",3000.0,19,ProductType.ELCTRONICS),
    p
]
console.log("Printing product low on stock")
for(let p of pList){
    if(p.getStock()<25){
        p.display();
    }
}