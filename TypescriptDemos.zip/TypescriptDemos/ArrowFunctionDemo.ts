import {Product} from './Product'
import {ProductType} from './ProductType'
var f=(p1:string,p2:string)=>console.log(p1+p2)
f("Hello","World")
var p:Product=new Product(1001,"Jeans",499.00,35,ProductType.APPAREL);
console.log(typeof(f))
var pList:Product[]=[
    new Product(1002,"T-Shirt",200.0,20,ProductType.APPAREL),new Product(1003,"Helmet",3000.0,19,ProductType.AUTOMOBILE),p
]
pList.forEach(element => {
    if(element.getPrice()>200){
        console.log(element);
    }
    
});