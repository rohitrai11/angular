"use strict";
exports.__esModule = true;
var Product_1 = require("./Product");
var ProductType_1 = require("./ProductType");
var p = new Product_1.Product(1001, "Jeans", 499.00, 35, ProductType_1.ProductType.APPAREL);
p.display();
var pList = [
    new Product_1.Product(1002, "T-Shirt", 200.0, 20, ProductType_1.ProductType.AUTOMOBILE),
    new Product_1.Product(1003, "Helmet", 3000.0, 19, ProductType_1.ProductType.ELCTRONICS),
    p
];
console.log("Printing product low on stock");
for (var _i = 0, pList_1 = pList; _i < pList_1.length; _i++) {
    var p_1 = pList_1[_i];
    if (p_1.getStock() < 25) {
        p_1.display();
    }
}
