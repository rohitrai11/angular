var movies:object[]=[{"movieName":"Star Wars","rating":5},{"movieName":"Titanic","rating":4.5},{"movieName":"Terminator","rating":3}]
var filteredMovie:object[]=[];
function filterMovies(movieList:object[]):void{
     for(let m of movieList){
         if(m["rating"]>4){
             filteredMovie.push(m);
         }
     }
}

filterMovies(movies)
for(let m of filteredMovie){
    console.log(m);
}