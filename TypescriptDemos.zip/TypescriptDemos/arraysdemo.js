var movieArray = [
    { "movieName": "StarWars", "rating": 4 },
    { "movieName": "Rambo1", "rating": 3 },
    { "movieName": "Entrapment", "rating": 4.5 }
];
var highRatedMoives = [];
for (var _i = 0, movieArray_1 = movieArray; _i < movieArray_1.length; _i++) {
    var m = movieArray_1[_i];
    if (m["rating"] >= 4) {
        highRatedMoives.push(m);
    }
}
for (var _a = 0, highRatedMoives_1 = highRatedMoives; _a < highRatedMoives_1.length; _a++) {
    var m = highRatedMoives_1[_a];
    console.log("Movie Name is " + m["movieName"]);
    console.log("Movie rating " + m["rating"]);
}
