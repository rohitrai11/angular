import {ProductType} from './ProductType'
export class Product{
    
    constructor(private id:number,private name:string,
        private price:number,private stock:number,
    private productType:ProductType){
        }
    public getId():number{
        return this.id;
    }
    public getName():string{
        return this.name;
    }
    public getPrice():number{
        return this.price;
    }
    public getStock():number{
        return this.stock;
    }
    public display():void{
        console.log("Id is "+this.id+" Name is\
        "+this.name+" Price "+this.price+" Stock "+this.stock+ProductType[this.productType])
        
    
    }
}