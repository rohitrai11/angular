import {Product} from './product';
export interface Billing{
   
   calculateBill(productId:number,quantity:number,productList:Product[]):void;
}