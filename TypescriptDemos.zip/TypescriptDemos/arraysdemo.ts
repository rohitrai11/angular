var movieArray:object[]=[
{"movieName":"StarWars","rating":4},
{"movieName":"Rambo1","rating":3},
{"movieName":"Entrapment","rating":4.5}
]
var highRatedMoives:object[]=[];
for(let m of movieArray){
   if(m["rating"]>=4){
       highRatedMoives.push(m)
   }
}
for(let m of highRatedMoives){
    console.log("Movie Name is "+m["movieName"]);
    console.log("Movie rating "+m["rating"]);
}