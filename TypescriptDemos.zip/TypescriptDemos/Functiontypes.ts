function defaultDemo(param1:string="1",param2:string,param3:string="5"){
    console.log(param1+" "+param2+" "+param3);
}
defaultDemo(undefined,"4");






function optionalDemo(param1:string,param2:string,param3?:string){
    if(param3==undefined){
        param3="5";
    }
    console.log(param1+" "+param2+" "+param3);

}
optionalDemo("3","4");
function restDemo(param1:string,...param2:string[]):void{
       console.log(param1+" "+param2)
}
restDemo("1","2","6","8")