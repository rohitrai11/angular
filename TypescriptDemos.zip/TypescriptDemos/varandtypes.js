var flag = true;
if (flag) {
    var myname = void 0;
    console.log(typeof (myname));
    myname = "success";
    console.log(typeof (myname));
}
else {
    var myname = "failure";
}
