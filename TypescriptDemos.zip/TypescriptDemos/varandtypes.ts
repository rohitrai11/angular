var flag:boolean=true;
if(flag){
    let myname:any;
    console.log(typeof(myname));
    myname="success";
    console.log(typeof(myname))
}
else{
    let myname:string="failure"
}
