function defaultDemo(param1, param2, param3) {
    if (param1 === void 0) { param1 = "1"; }
    if (param3 === void 0) { param3 = "5"; }
    console.log(param1 + " " + param2 + " " + param3);
}
defaultDemo(undefined, "4");
function optionalDemo(param1, param2, param3) {
    if (param3 == undefined) {
        param3 = "5";
    }
    console.log(param1 + " " + param2 + " " + param3);
}
optionalDemo("3", "4");
function restDemo(param1) {
    var param2 = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        param2[_i - 1] = arguments[_i];
    }
    console.log(param1 + " " + param2);
}
restDemo("1", "2", "6", "8");
