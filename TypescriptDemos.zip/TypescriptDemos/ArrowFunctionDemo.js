"use strict";
exports.__esModule = true;
var Product_1 = require("./Product");
var ProductType_1 = require("./ProductType");
var f = function (p1, p2) { return console.log(p1 + p2); };
f("Hello", "World");
var p = new Product_1.Product("Jeans", 499.00, 35, ProductType_1.ProductType.APPAREL);
console.log(typeof (f));
var pList = [
    new Product_1.Product("T-Shirt", 200.0, 20, ProductType_1.ProductType.APPAREL), new Product_1.Product("Helmet", 3000.0, 19, ProductType_1.ProductType.AUTOMOBILE), p
];
pList.forEach(function (element) {
    if (element.getPrice() > 200) {
        console.log(element);
    }
});
