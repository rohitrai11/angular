"use strict";
exports.__esModule = true;
var ProductType;
(function (ProductType) {
    ProductType[ProductType["APPAREL"] = 2001] = "APPAREL";
    ProductType[ProductType["ELCTRONICS"] = 2002] = "ELCTRONICS";
    ProductType[ProductType["AUTOMOBILE"] = 2003] = "AUTOMOBILE";
})(ProductType = exports.ProductType || (exports.ProductType = {}));
