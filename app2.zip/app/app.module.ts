import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule,FormGroup } from '@angular/forms';


import { AppComponent } from './app.component';
import { DisplayboatComponent } from './displayboat/displayboat.component';







@NgModule({
  declarations: [
    AppComponent,
    DisplayboatComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
