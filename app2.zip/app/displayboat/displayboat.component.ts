import { Component, OnInit } from '@angular/core';
import { Boat } from '../Boat';

@Component({
  selector: 'displayboat',
  templateUrl: './displayboat.component.html',
  styleUrls: ['./displayboat.component.css']
})
export class DisplayboatComponent implements OnInit {
  show: boolean = false;
  boatToDisplay:Boat;
  myclass:string;
  b:string="blue";
  g:string="green";
  selectedRow:number;
  flag:boolean=false;
  bcolor:string="pink";
  constructor() { 
    
  }
  setClickedRow(rowNo:number){
    alert(rowNo)
    this.selectedRow=rowNo;
  }
  showBoat(boat:Boat) {
    this.boatToDisplay=boat;
   this.show=this.show?false:true;
}
changeStyle(){
  this.flag=this.flag?false:true;
  
  this.myclass="styleclass1";
}
changeStyle2(){
  this.flag=this.flag?false:true;
  this.myclass="styleclass2";
}
BOATS: Boat[] = [
  new Boat("1001","Houseboat","Allepy",999.0,5,.8,new Date(2019,3,12),"This is house boat service",""),
  new Boat("1002","Houseboat","Goa",999.0,5,.8,new Date(2019,2,12),"This is house boat service",""),
  new Boat("1003","Houseboat","Allepy",499.0,5,.8,new Date(2019,7,12),"This is house boat service","")
  
];   
  

  ngOnInit() {
  }

}
